<?php
/**
 * メールフォーム非公開時表示ページ
 * 呼出箇所：メールフォーム
 */
?>


<h2><?php $this->BcBaser->contentsTitle() ?></h2>

<h3>受付中止</h3>

<div><p>現在、受付を中止しています。</p></div>
