<?php
$title = 'Pickles 2 Export';
$description = 'Pickles 2 からエクスポートしたデータです。';
$author = 'Pickles 2 Project';
$url = 'http://pickles2.pxt.jp/';
